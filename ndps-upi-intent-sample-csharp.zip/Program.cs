using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;

const string reqEncKey = "A4476C2062FFA58980DC8F79EB6A799E";
const string reqSalt = "A4476C2062FFA58980DC8F79EB6A799E";

const string resDecKey = "75AEF0FA1B94B3C10D4F5B268F757F11";
const string resSalt = "75AEF0FA1B94B3C10D4F5B268F757F11";

const string merchId = "456669";
const string merchPass = "Test@123";
const string prodId = "NSE";

// Request Hash Key
const string reqHashKey = "KEY123657234";

// Response Hash Key
const string resHashKey = "KEYRESP123657234";

const string authUrl =
    "https://paynetzuat.atomtech.in/ots/payment/txn";

const int iterations = 65536;

byte[] iv =
{
    0, 1, 2, 3,
    4, 5, 6, 7,
    8, 9, 10, 11,
    12, 13, 14, 15
};


// ============================================================
// ENCRYPT
// ============================================================

string Encrypt(string text)
{
    byte[] password =
        Encoding.UTF8.GetBytes(reqEncKey);

    byte[] salt =
        Encoding.UTF8.GetBytes(reqSalt);

    byte[] derivedKey =
        Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            iterations,
            HashAlgorithmName.SHA512,
            32
        );

    using Aes aes = Aes.Create();

    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    aes.Key = derivedKey;
    aes.IV = iv;

    using ICryptoTransform encryptor =
        aes.CreateEncryptor();

    byte[] plainBytes =
        Encoding.UTF8.GetBytes(text);

    byte[] encryptedBytes =
        encryptor.TransformFinalBlock(
            plainBytes,
            0,
            plainBytes.Length
        );

    return Convert.ToHexString(
        encryptedBytes
    ).ToLowerInvariant();
}


// ============================================================
// DECRYPT
// ============================================================

string Decrypt(string encryptedText)
{
    encryptedText =
        encryptedText.Trim();

    try
    {
        encryptedText =
            Uri.UnescapeDataString(
                encryptedText
            );
    }
    catch
    {
    }

    encryptedText =
        encryptedText
            .Replace(" ", "")
            .Replace("\r", "")
            .Replace("\n", "")
            .Replace("\t", "");

    if (encryptedText.Length % 2 != 0)
    {
        throw new Exception(
            "Invalid HEX encrypted response length"
        );
    }

    byte[] encryptedBytes =
        Convert.FromHexString(
            encryptedText
        );

    byte[] password =
        Encoding.UTF8.GetBytes(resDecKey);

    byte[] salt =
        Encoding.UTF8.GetBytes(resSalt);

    byte[] derivedKey =
        Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            iterations,
            HashAlgorithmName.SHA512,
            32
        );

    using Aes aes = Aes.Create();

    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    aes.Key = derivedKey;
    aes.IV = iv;

    using ICryptoTransform decryptor =
        aes.CreateDecryptor();

    byte[] decryptedBytes =
        decryptor.TransformFinalBlock(
            encryptedBytes,
            0,
            encryptedBytes.Length
        );

    return Encoding.UTF8.GetString(
        decryptedBytes
    );
}


// ============================================================
// REQUEST SIGNATURE
// ============================================================
//
// Sequence:
//
// merchantId
// + TxnPassword
// + MerchantTxnID
// + Payment Mode
// + Total amount
// + currency
// + stage
//
// Example:
//
// 456669Test@123SL_UI@123SL1.00INR1
//
// HMAC-SHA512 using:
// KEY123657234
// ============================================================

string GenerateRequestSignature(
    string merchantId,
    string txnPassword,
    string merchantTxnId,
    string paymentMode,
    string totalAmount,
    string currency,
    string stage)
{
    string signatureString =
        merchantId +
        txnPassword +
        merchantTxnId +
        paymentMode +
        decimal.Parse(totalAmount)
            .ToString("0.00") +
        currency +
        stage;

    Console.WriteLine();
    Console.WriteLine("======================================");
    Console.WriteLine("REQUEST SIGNATURE");
    Console.WriteLine("======================================");

    Console.WriteLine(
        "Signature Plain Value:"
    );

    Console.WriteLine(
        signatureString
    );

    byte[] keyBytes =
        Encoding.UTF8.GetBytes(
            reqHashKey
        );

    byte[] dataBytes =
        Encoding.UTF8.GetBytes(
            signatureString
        );

    using HMACSHA512 hmac =
        new HMACSHA512(keyBytes);

    byte[] hash =
        hmac.ComputeHash(dataBytes);

    string signature =
        Convert.ToHexString(
            hash
        ).ToLowerInvariant();

    Console.WriteLine();
    Console.WriteLine(
        "Generated Request Signature:"
    );

    Console.WriteLine(
        signature
    );

    Console.WriteLine(
        "======================================"
    );

    return signature;
}


// ============================================================
// RESPONSE SIGNATURE
// ============================================================

string GenerateResponseSignature(
    string signatureString)
{
    byte[] keyBytes =
        Encoding.UTF8.GetBytes(
            resHashKey
        );

    byte[] dataBytes =
        Encoding.UTF8.GetBytes(
            signatureString
        );

    using HMACSHA512 hmac =
        new HMACSHA512(keyBytes);

    byte[] hash =
        hmac.ComputeHash(dataBytes);

    return Convert.ToHexString(
        hash
    ).ToLowerInvariant();
}


// ============================================================
// EXTRACT ENCDATA
// ============================================================

string GetEncData(string responseBody)
{
    if (string.IsNullOrWhiteSpace(responseBody))
    {
        throw new Exception(
            "Atom response body is empty"
        );
    }

    string body =
        responseBody.Trim();

    int index =
        body.IndexOf(
            "encData=",
            StringComparison.OrdinalIgnoreCase
        );

    if (index < 0)
    {
        throw new Exception(
            "encData not found in Atom response"
        );
    }

    string value =
        body.Substring(
            index + "encData=".Length
        );

    int ampersand =
        value.IndexOf("&");

    if (ampersand >= 0)
    {
        value =
            value.Substring(
                0,
                ampersand
            );
    }

    return Uri.UnescapeDataString(
        value
    ).Trim();
}


// ============================================================
// CREATE TRANSACTION ID
// ============================================================

string txnId =
    "Invoice" +
    DateTimeOffset.UtcNow
        .ToUnixTimeMilliseconds();


// ============================================================
// PAYMENT VALUES
// ============================================================

string paymentMode = "SL";

string amount = "1.00";

string currency = "INR";

string stage = "1";

string email = "test@gm.com";

string phone = "8888888888";


// ============================================================
// GENERATE REQUEST SIGNATURE
// ============================================================

string signature =
    GenerateRequestSignature(
        merchId,
        merchPass,
        txnId,
        paymentMode,
        amount,
        currency,
        stage
    );


// ============================================================
// CREATE PAYMENT JSON
// ============================================================

string jsonData = $$"""
{
    "payInstrument": {
        "headDetails": {
            "version": "OTSv1.1",
            "payMode": "SL",
            "channel": "ECOMM",
            "api": "SALE",
            "stage": 1,
            "platform": "APP"
        },
        "merchDetails": {
            "merchId": "{{merchId}}",
            "userId": "",
            "password": "{{merchPass}}",
            "merchTxnId": "{{txnId}}",
            "merchType": "M",
            "mccCode": 6211,
            "merchTxnDate": "{{DateTime.Now:yyyy-MM-dd HH:mm:ss}}"
        },
        "payDetails": {
            "prodDetails": [
                {
                    "prodName": "{{prodId}}",
                    "prodAmount": "{{amount}}"
                }
            ],
            "amount": "{{amount}}",
            "surchargeAmount": "0.00",
            "totalAmount": "{{amount}}",
            "clientCode": "12345",
            "platfromOS": "Android",
            "txnCurrency": "{{currency}}",
            "custAccNo": "1234567890",
            "custAccIfsc": "ICICI1234",
            "signature": "{{signature}}"
        },
        "responseUrls": {
            "returnUrl": "https://pgtest.atomtech.in/paynetzclient/ResponseParam.jsp"
        },
        "payModeSpecificData": {
            "subChannel": [
                "UP"
            ]
        },
        "custDetails": {
            "custEmail": "{{email}}",
            "custMobile": "{{phone}}"
        }
    }
}
""";


Console.WriteLine();
Console.WriteLine("======================================");
Console.WriteLine("ATOM .NET PAYMENT TEST");
Console.WriteLine("======================================");

Console.WriteLine();
Console.WriteLine("Transaction ID:");
Console.WriteLine(txnId);


// ============================================================
// ENCRYPT REQUEST
// ============================================================

string encryptedRequest =
    Encrypt(jsonData);

Console.WriteLine();
Console.WriteLine("Encrypted Request:");
Console.WriteLine(encryptedRequest);

Console.WriteLine();
Console.WriteLine(
    "Encrypted Length: " +
    encryptedRequest.Length
);


// ============================================================
// HTTP REQUEST
// ============================================================

using HttpClient client =
    new HttpClient();

client.Timeout =
    TimeSpan.FromSeconds(60);

using FormUrlEncodedContent form =
    new FormUrlEncodedContent(
        new[]
        {
            new KeyValuePair<string, string>(
                "encData",
                encryptedRequest
            ),

            new KeyValuePair<string, string>(
                "merchId",
                merchId
            )
        }
    );


Console.WriteLine();
Console.WriteLine("Calling Atom UAT...");

HttpResponseMessage response =
    await client.PostAsync(
        authUrl,
        form
    );

string responseBody =
    await response.Content.ReadAsStringAsync();


Console.WriteLine();
Console.WriteLine("HTTP STATUS:");

Console.WriteLine(
    $"{(int)response.StatusCode} {response.StatusCode}"
);


Console.WriteLine();
Console.WriteLine("ATOM RAW RESPONSE:");

Console.WriteLine(
    responseBody
);


// ============================================================
// EXTRACT ENCDATA
// ============================================================

string encryptedResponse =
    GetEncData(responseBody);


Console.WriteLine();
Console.WriteLine(
    "Encrypted Response Length: " +
    encryptedResponse.Length
);


// ============================================================
// DECRYPT
// ============================================================

string decryptedData =
    Decrypt(encryptedResponse);


Console.WriteLine();
Console.WriteLine("======================================");
Console.WriteLine("DECRYPTED RESPONSE");
Console.WriteLine("======================================");

Console.WriteLine(
    decryptedData
);


// ============================================================
// CHECK STATUS
// ============================================================

Console.WriteLine();
Console.WriteLine("======================================");

if (
    decryptedData.Contains(
        "\"statusCode\":\"OTS0351\""
    )
)
{
    Console.WriteLine(
        "TRANSACTION INITIATED SUCCESSFULLY"
    );

    Console.WriteLine(
        "======================================"
    );

    int qrIndex =
        decryptedData.IndexOf(
            "\"qrString\"",
            StringComparison.OrdinalIgnoreCase
        );

    if (qrIndex >= 0)
    {
        Console.WriteLine();
        Console.WriteLine(
            "QR String field found in response."
        );
    }
}
else
{
    Console.WriteLine(
        "TRANSACTION INITIALIZATION FAILED"
    );

    Console.WriteLine(
        "======================================"
    );
}
