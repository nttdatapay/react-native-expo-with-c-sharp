using System;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient();

var app = builder.Build();


// ================================================================
// ATOM CONFIGURATION
// ================================================================

const string reqEncKey =
    "A4476C2062FFA58980DC8F79EB6A799E";

const string reqSalt =
    "A4476C2062FFA58980DC8F79EB6A799E";

const string resDecKey =
    "75AEF0FA1B94B3C10D4F5B268F757F11";

const string resSalt =
    "75AEF0FA1B94B3C10D4F5B268F757F11";

const string merchId =
    "456669";

const string merchPass =
    "Test@123";

const string prodId =
    "NSE";

const string reqHashKey =
    "KEY123657234";

const string resHashKey =
    "KEYRESP123657234";

const string authUrl =
    "https://paynetzuat.atomtech.in/ots/payment/txn";

const int iterations = 65536;

byte[] iv =
{
    0, 1, 2, 3,
    4, 5, 6, 7,
    8, 9, 10, 11,
    12, 13, 14, 15
};


// ================================================================
// POST /init-upi-intent
// ================================================================

app.MapPost("/init-upi-intent", async (
    PaymentRequest request,
    IHttpClientFactory httpClientFactory) =>
{
    try
    {
        // ============================================================
        // VALIDATION
        // ============================================================

        if (request.Amount <= 0)
        {
            return Results.BadRequest(new
            {
                success = false,
                message = "amount is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.TxnId))
        {
            return Results.BadRequest(new
            {
                success = false,
                message = "txnId is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.Email))
        {
            return Results.BadRequest(new
            {
                success = false,
                message = "email is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.Phone))
        {
            return Results.BadRequest(new
            {
                success = false,
                message = "phone is required"
            });
        }


        // ============================================================
        // PAYMENT VALUES
        // ============================================================

        string txnId =
            request.TxnId;

        string amount =
            request.Amount.ToString("0.00");


        // ============================================================
        // REQUEST SIGNATURE
        //
        // merchantId
        // + TxnPassword
        // + MerchantTxnID
        // + Payment Mode
        // + Total Amount
        // + Currency
        // + Stage
        // ============================================================

        string signatureString =
            merchId +
            merchPass +
            txnId +
            "SL" +
            amount +
            "INR" +
            "1";


        string requestSignature =
            GenerateHmacSha512(
                signatureString,
                reqHashKey
            );


        Console.WriteLine();
        Console.WriteLine("==========================================");
        Console.WriteLine("ATOM UPI INTENT REQUEST");
        Console.WriteLine("==========================================");

        Console.WriteLine(
            "Transaction ID : " +
            txnId
        );

        Console.WriteLine(
            "Amount         : " +
            amount
        );

        Console.WriteLine(
            "Signature Data : " +
            signatureString
        );

        Console.WriteLine(
            "Signature      : " +
            requestSignature
        );


        // ============================================================
        // ATOM REQUEST
        //
        // THIS STRUCTURE MATCHES THE WORKING NODE.JS REQUEST
        // ============================================================

        var atomRequest = new
        {
            payInstrument = new
            {
                headDetails = new
                {
                    version = "OTSv1.1",
                    payMode = "SL",
                    channel = "ECOMM",
                    api = "SALE",

                    // IMPORTANT: NUMBER, NOT STRING
                    stage = 1,

                    platform = "APP"
                },

                merchDetails = new
                {
                    merchId = merchId,
                    userId = "",
                    password = merchPass,
                    merchTxnId = txnId,
                    merchType = "M",

                    // IMPORTANT: NUMBER, NOT STRING
                    mccCode = 6211,

                    merchTxnDate =
                        DateTime.Now.ToString(
                            "yyyy-MM-dd HH:mm:ss"
                        )
                },

                payDetails = new
                {
                    // IMPORTANT:
                    // Working Node uses prodDetails
                    prodDetails = new[]
                    {
                        new
                        {
                            prodName = prodId,
                            prodAmount = amount
                        }
                    },

                    amount = amount,

                    // IMPORTANT:
                    // Working Node uses surchargeAmount
                    surchargeAmount = "0.00",

                    totalAmount = amount,

                    clientCode = "12345",

                    platfromOS = "Android",

                    txnCurrency = "INR",

                    custAccNo = "1234567890",

                    custAccIfsc = "ICICI1234",

                    // DYNAMIC SIGNATURE
                    signature = requestSignature
                },

                responseUrls = new
                {
                    returnUrl =
                        "https://pgtest.atomtech.in/paynetzclient/ResponseParam.jsp"
                },

                payModeSpecificData = new
                {
                    subChannel = new[]
                    {
                        "UP"
                    }
                },

                custDetails = new
                {
                    custEmail = request.Email,
                    custMobile = request.Phone
                }
            }
        };


        // ============================================================
        // SERIALIZE JSON
        // ============================================================

        string plainJson =
            JsonSerializer.Serialize(
                atomRequest
            );


        Console.WriteLine();
        Console.WriteLine("Plain Request:");
        Console.WriteLine(plainJson);


        // ============================================================
        // ENCRYPT
        // ============================================================

        string encryptedRequest =
            Encrypt(
                plainJson,
                reqEncKey,
                reqSalt,
                iterations,
                iv
            );


        Console.WriteLine();
        Console.WriteLine("Encrypted Request:");

        Console.WriteLine(
            encryptedRequest
        );

        Console.WriteLine();
        Console.WriteLine(
            "Encrypted Request Length: " +
            encryptedRequest.Length
        );


        // ============================================================
        // ATOM FORM DATA
        //
        // Equivalent to Node:
        //
        // request.form({
        //     encData: encDataR,
        //     merchId: merchId
        // });
        //
        // ============================================================

        using var formContent =
            new FormUrlEncodedContent(
                new[]
                {
                    new KeyValuePair<string, string>(
                        "encData",
                        encryptedRequest
                    ),

                    new KeyValuePair<string, string>(
                        "merchId",
                        merchId
                    )
                }
            );


        // ============================================================
        // HTTP CLIENT
        // ============================================================

        HttpClient client =
            httpClientFactory.CreateClient();

        client.Timeout =
            TimeSpan.FromSeconds(60);


        Console.WriteLine();
        Console.WriteLine("==========================================");
        Console.WriteLine("CALLING ATOM UAT");
        Console.WriteLine("==========================================");

        Console.WriteLine(
            "URL: " + authUrl
        );


        // ============================================================
        // CALL ATOM
        // ============================================================

        HttpResponseMessage atomResponse =
            await client.PostAsync(
                authUrl,
                formContent
            );


        string rawResponse =
            await atomResponse.Content.ReadAsStringAsync();


        Console.WriteLine();
        Console.WriteLine("Atom HTTP Status:");

        Console.WriteLine(
            (int)atomResponse.StatusCode +
            " " +
            atomResponse.StatusCode
        );


        Console.WriteLine();
        Console.WriteLine("Atom Raw Response:");

        Console.WriteLine(
            rawResponse
        );


        // ============================================================
        // CHECK HTML ERROR
        // ============================================================

        if (
            rawResponse.Contains(
                "<title>OTS ERROR</title>",
                StringComparison.OrdinalIgnoreCase
            )
        )
        {
            return Results.BadRequest(new
            {
                success = false,
                message = "Atom returned OTS ERROR",
                atomHttpStatus =
                    (int)atomResponse.StatusCode
            });
        }


        // ============================================================
        // GET encData
        // ============================================================

        string encryptedResponse =
            GetEncData(
                rawResponse
            );


        if (
            string.IsNullOrWhiteSpace(
                encryptedResponse
            )
        )
        {
            return Results.BadRequest(new
            {
                success = false,
                message =
                    "encData not found in Atom response",
                rawResponse =
                    rawResponse
            });
        }


        Console.WriteLine();
        Console.WriteLine(
            "Encrypted Response Length: " +
            encryptedResponse.Length
        );


        // ============================================================
        // DECRYPT RESPONSE
        // ============================================================

        string decryptedResponse =
            Decrypt(
                encryptedResponse,
                resDecKey,
                resSalt,
                iterations,
                iv
            );


        Console.WriteLine();
        Console.WriteLine("==========================================");
        Console.WriteLine("DECRYPTED ATOM RESPONSE");
        Console.WriteLine("==========================================");

        Console.WriteLine(
            decryptedResponse
        );


        // ============================================================
        // PARSE RESPONSE
        // ============================================================

        using JsonDocument responseDocument =
            JsonDocument.Parse(
                decryptedResponse
            );


        JsonElement root =
            responseDocument.RootElement;


        // ============================================================
        // STATUS CODE
        // ============================================================

        string statusCode =
            FindJsonString(
                root,
                "statusCode"
            );


        Console.WriteLine();
        Console.WriteLine(
            "Status Code: " +
            statusCode
        );


        // ============================================================
        // SUCCESS
        // ============================================================

        if (
            statusCode == "OTS0351"
        )
        {
            // Working Node path:
            //
            // jsonData
            //   .payInstrument
            //   .payModeSpecificData
            //   .bankDetails
            //   .qrString

            string qrString = "";


            if (
                root.TryGetProperty(
                    "payInstrument",
                    out JsonElement payInstrument
                )
            )
            {
                if (
                    payInstrument.TryGetProperty(
                        "payModeSpecificData",
                        out JsonElement modeData
                    )
                )
                {
                    if (
                        modeData.TryGetProperty(
                            "bankDetails",
                            out JsonElement bankDetails
                        )
                    )
                    {
                        if (
                            bankDetails.TryGetProperty(
                                "qrString",
                                out JsonElement qrElement
                            )
                        )
                        {
                            qrString =
                                qrElement.GetString() ?? "";
                        }
                    }
                }
            }


            // Fallback
            if (
                string.IsNullOrWhiteSpace(
                    qrString
                )
            )
            {
                qrString =
                    FindJsonString(
                        root,
                        "qrString"
                    );
            }


            Console.WriteLine();
            Console.WriteLine(
                "QR String:"
            );

            Console.WriteLine(
                qrString
            );


            // ========================================================
            // FINAL SUCCESS RESPONSE
            // ========================================================

            return Results.Ok(new
            {
                success = true,
                message = "Transaction initiated",
                amount = request.Amount,
                merchTxnId = txnId,
                qrString = qrString
            });
        }


        // ============================================================
        // FAILURE
        // ============================================================

        string responseMessage =
            FindJsonString(
                root,
                "message"
            );


        if (
            string.IsNullOrWhiteSpace(
                responseMessage
            )
        )
        {
            responseMessage =
                FindJsonString(
                    root,
                    "statusDescription"
                );
        }


        if (
            string.IsNullOrWhiteSpace(
                responseMessage
            )
        )
        {
            responseMessage =
                "Transaction initialization failed";
        }


        return Results.BadRequest(new
        {
            success = false,
            message = responseMessage,
            statusCode = statusCode,
            merchTxnId = txnId,
            data = root
        });
    }
    catch (Exception ex)
    {
        Console.WriteLine();
        Console.WriteLine("==========================================");
        Console.WriteLine("ERROR");
        Console.WriteLine("==========================================");

        Console.WriteLine(
            ex.ToString()
        );


        return Results.StatusCode(500);
    }
});


// ================================================================
// HMAC SHA512
// ================================================================

static string GenerateHmacSha512(
    string input,
    string key)
{
    using HMACSHA512 hmac =
        new HMACSHA512(
            Encoding.UTF8.GetBytes(
                key
            )
        );


    byte[] hash =
        hmac.ComputeHash(
            Encoding.UTF8.GetBytes(
                input
            )
        );


    return Convert.ToHexString(
        hash
    ).ToLowerInvariant();
}


// ================================================================
// AES ENCRYPTION
// ================================================================

static string Encrypt(
    string plainText,
    string password,
    string salt,
    int iterations,
    byte[] iv)
{
    using var deriveBytes =
        new Rfc2898DeriveBytes(
            password,
            Encoding.UTF8.GetBytes(
                salt
            ),
            iterations,
            HashAlgorithmName.SHA512
        );


    byte[] key =
        deriveBytes.GetBytes(32);


    using Aes aes =
        Aes.Create();


    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;


    aes.Key = key;
    aes.IV = iv;


    using ICryptoTransform encryptor =
        aes.CreateEncryptor();


    byte[] input =
        Encoding.UTF8.GetBytes(
            plainText
        );


    byte[] encrypted =
        encryptor.TransformFinalBlock(
            input,
            0,
            input.Length
        );


    return Convert.ToHexString(
        encrypted
    ).ToLowerInvariant();
}


// ================================================================
// AES DECRYPTION
// ================================================================

static string Decrypt(
    string encryptedHex,
    string password,
    string salt,
    int iterations,
    byte[] iv)
{
    string cleanHex =
        encryptedHex
            .Trim()
            .Replace("\\", "")
            .Replace("\"", "")
            .Replace("\r", "")
            .Replace("\n", "")
            .Replace(" ", "");


    // In case response contains URL encoding
    try
    {
        cleanHex =
            Uri.UnescapeDataString(
                cleanHex
            );
    }
    catch
    {
        // Ignore
    }


    byte[] encrypted =
        Convert.FromHexString(
            cleanHex
        );


    using var deriveBytes =
        new Rfc2898DeriveBytes(
            password,
            Encoding.UTF8.GetBytes(
                salt
            ),
            iterations,
            HashAlgorithmName.SHA512
        );


    byte[] key =
        deriveBytes.GetBytes(32);


    using Aes aes =
        Aes.Create();


    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;


    aes.Key = key;
    aes.IV = iv;


    using ICryptoTransform decryptor =
        aes.CreateDecryptor();


    byte[] decrypted =
        decryptor.TransformFinalBlock(
            encrypted,
            0,
            encrypted.Length
        );


    return Encoding.UTF8.GetString(
        decrypted
    );
}


// ================================================================
// GET encData FROM ATOM RESPONSE
// ================================================================

static string GetEncData(
    string response)
{
    if (
        string.IsNullOrWhiteSpace(
            response
        )
    )
    {
        return "";
    }


    string body =
        response.Trim();


    // ------------------------------------------------------------
    // FORM URL ENCODED RESPONSE
    // ------------------------------------------------------------

    string[] parts =
        body.Split('&');


    foreach (
        string part
        in parts
    )
    {
        string[] keyValue =
            part.Split(
                '=',
                2
            );


        if (
            keyValue.Length == 2 &&
            keyValue[0].Equals(
                "encData",
                StringComparison.OrdinalIgnoreCase
            )
        )
        {
            return Uri.UnescapeDataString(
                keyValue[1]
            ).Trim();
        }
    }


    // ------------------------------------------------------------
    // JSON RESPONSE
    // ------------------------------------------------------------

    try
    {
        using JsonDocument document =
            JsonDocument.Parse(
                body
            );


        if (
            document.RootElement.TryGetProperty(
                "encData",
                out JsonElement encData
            )
        )
        {
            return encData
                .GetString() ?? "";
        }
    }
    catch
    {
        // Not JSON
    }


    return "";
}


// ================================================================
// FIND JSON STRING RECURSIVELY
// ================================================================

static string FindJsonString(
    JsonElement element,
    string propertyName)
{
    if (
        element.ValueKind ==
        JsonValueKind.Object
    )
    {
        foreach (
            JsonProperty property
            in element.EnumerateObject()
        )
        {
            if (
                property.Name.Equals(
                    propertyName,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                if (
                    property.Value.ValueKind ==
                    JsonValueKind.String
                )
                {
                    return property.Value
                        .GetString() ?? "";
                }


                if (
                    property.Value.ValueKind ==
                    JsonValueKind.Number
                )
                {
                    return property.Value
                        .ToString();
                }
            }


            string result =
                FindJsonString(
                    property.Value,
                    propertyName
                );


            if (
                !string.IsNullOrWhiteSpace(
                    result
                )
            )
            {
                return result;
            }
        }
    }


    if (
        element.ValueKind ==
        JsonValueKind.Array
    )
    {
        foreach (
            JsonElement item
            in element.EnumerateArray()
        )
        {
            string result =
                FindJsonString(
                    item,
                    propertyName
                );


            if (
                !string.IsNullOrWhiteSpace(
                    result
                )
            )
            {
                return result;
            }
        }
    }


    return "";
}


// ================================================================
// START APPLICATION
// ================================================================

app.Run();


// ================================================================
// REQUEST MODEL
// ================================================================

public class PaymentRequest
{
    [JsonPropertyName("amount")]
    public decimal Amount { get; set; }

    [JsonPropertyName("txnId")]
    public string TxnId { get; set; } = "";

    [JsonPropertyName("email")]
    public string Email { get; set; } = "";

    [JsonPropertyName("phone")]
    public string Phone { get; set; } = "";
}
